const functions = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {GoogleGenerativeAI} = require("@google/generative-ai");

// Initialize the client with the API key and explicitly set the stable API
// version. This is the fix for the "not found for API version v1beta"
// error.
const genAI = new GoogleGenerativeAI(
    process.env.GEMINI_API_KEY, {apiVersion: "v1"});

// Use the stable 'gemini-pro' model for robust API compatibility.
const model = genAI.getGenerativeModel({model: "gemini-pro"});

exports.getGeminiResponse = onRequest(
    {
      cors: [
        "http://127.0.0.1:5500",
        "https://tutorbot-184ec.web.app",
      ],
      region: "us-central1",
      secrets: ["GEMINI_API_KEY"],
    },
    async (req, res) => {
      try {
        const {contents} = req.body;
        if (!contents) {
          functions.logger.error("Request body missing 'contents' array.");
          res.status(400).json({
            error: "Request body must contain a 'contents' array.",
          });
          return;
        }

        // Use generateContent, which is simpler for stateless calls
        const result = await model.generateContent({contents});

        if (
          !result || !result.response
        ) {
          throw new Error("Invalid response structure from Gemini API.");
        }

        // Check for safety blocks or empty candidates array
        if (result.response.candidates.length === 0) {
          const feedback = result.response.promptFeedback || {};
          functions.logger.warn("Gemini response was blocked or empty.", {
            finishReason: feedback.blockReason,
            safetyRatings: feedback.safetyRatings,
          });
          // Use 400 Bad Request, as the block is due to the client's input.
          res.status(400).json({
            error: "The AI response was blocked for safety reasons. " +
                   "Please check the curriculum content and try again.",
          });
          return;
        }

        const aiText = result.response.text();
        res.status(200).json({text: aiText});
      } catch (error) {
        functions.logger.error("Error calling Gemini API:", error);
        res.status(500).json({
          error: "Failed to get response from Gemini API.",
        });
      }
    });
